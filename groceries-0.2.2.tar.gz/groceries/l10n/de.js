OC.L10N.register(
	"groceries",
	{
		"Groceries": "Einkaufslisten",
		"Groceries on your phone": "Einkaufslisten auf dem Handy",
		"Open this address on your phone and add it to the home screen. You log in once; the app then keeps its own device password, which you can revoke any time under Security → Devices & sessions.": "Öffne diese Adresse auf dem Handy und füge sie zum Home-Bildschirm hinzu. Du meldest dich einmal an; die App behält danach ihr eigenes Gerätepasswort, das du jederzeit unter Sicherheit → Geräte & Sitzungen widerrufen kannst.",
		"iPhone / iPad (Safari)": "iPhone / iPad (Safari)",
		"Open the address in Safari.": "Öffne die Adresse in Safari.",
		"Tap the Share button, then \"Add to Home Screen\".": "Tippe auf „Teilen“ und dann auf „Zum Home-Bildschirm“.",
		"Open Groceries from the home screen and tap \"Connect to Nextcloud\".": "Öffne die App vom Home-Bildschirm und tippe auf „Mit Nextcloud verbinden“.",
		"QR code with the address of the app": "QR-Code mit der Adresse der App",
		"Scan the code with the phone camera, or open this address on the phone:": "Scanne den Code mit der Handykamera oder öffne diese Adresse auf dem Handy:",
		"Android (Chrome)": "Android (Chrome)",
		"Open the address in Chrome.": "Öffne die Adresse in Chrome.",
		"Tap \"Install app\" in the app or the browser menu (⋮ → \"Install app\").": "Tippe in der App auf „Installieren“ oder im Browsermenü auf ⋮ → „App installieren“."
	},
	"nplurals=2; plural=(n != 1);"
);
